.. include:: ../README.rst

.. toctree::
   :hidden:
   :name: mastertoc

   self
   configuration
   api

