from flask import Flask

testapp = Flask("testapp")
