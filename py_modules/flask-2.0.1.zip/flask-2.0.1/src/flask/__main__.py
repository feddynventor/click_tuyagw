from .cli import main

main()
