#!/bin/bash

# Checks the sources for some basic style guidelines and complexity.

flake8 --config=flake8.conf multiping demo.py

